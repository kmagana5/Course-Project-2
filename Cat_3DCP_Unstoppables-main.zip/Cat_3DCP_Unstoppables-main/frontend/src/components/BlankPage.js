// components/BlankPage.js
import React from 'react';
import './BlankPage.css';

const BlankPage = () => {
  return (
    <div className="BlankPage">
      <h2>This is a blank page</h2>
      {/* Add other elements as necessary */}
    </div>
  );
}

export default BlankPage;
